#pragma once
#include <cstring>
#include "log.h"

using namespace std;

int contains (const char *, const char *);
